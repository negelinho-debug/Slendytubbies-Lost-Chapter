import UIKit
import SceneKit
import QuartzCore
import AVFoundation
import UniformTypeIdentifiers

// LOST CHAPTER — noncommercial fan project with creator-attributed third-party models.
// SceneKit native 3D. Bundled community models are user supplied; verify rights before redistribution.

private func color(_ hex: UInt32, a: CGFloat = 1) -> UIColor {
    UIColor(red: CGFloat((hex >> 16) & 255) / 255,
            green: CGFloat((hex >> 8) & 255) / 255,
            blue: CGFloat(hex & 255) / 255, alpha: a)
}

private func material(_ hex: UInt32, emission: UInt32? = nil) -> SCNMaterial {
    let m = SCNMaterial()
    m.diffuse.contents = color(hex)
    m.specular.contents = color(0x222222)
    m.lightingModel = .blinn
    if let emission = emission { m.emission.contents = color(emission) }
    return m
}

private func box(_ w: CGFloat, _ h: CGFloat, _ d: CGFloat, _ hex: UInt32) -> SCNNode {
    let g = SCNBox(width: w, height: h, length: d, chamferRadius: 0.025)
    g.materials = [material(hex)]
    return SCNNode(geometry: g)
}

private struct Blocker {
    let x: Float
    let z: Float
    let halfW: Float
    let halfD: Float
}

private final class Pickup {
    var node: SCNNode
    var position: SCNVector3
    init(node: SCNNode, position: SCNVector3) {
        self.node = node
        self.position = position
    }
}

// Touch joystick works even without a game controller or a keyboard.
private final class Joystick: UIView {
    var direction = CGPoint.zero
    private let knob = UIView()
    private let ring = UIView()
    override init(frame: CGRect) {
        super.init(frame: frame)
        isMultipleTouchEnabled = false
        ring.layer.borderWidth = 2
        ring.layer.borderColor = UIColor.white.withAlphaComponent(0.37).cgColor
        ring.backgroundColor = UIColor.black.withAlphaComponent(0.25)
        addSubview(ring)
        knob.backgroundColor = color(0xD2F2E2, a: 0.57)
        knob.layer.borderWidth = 1.5
        knob.layer.borderColor = UIColor.white.withAlphaComponent(0.9).cgColor
        addSubview(knob)
    }
    required init?(coder: NSCoder) { fatalError("No storyboard") }
    override func layoutSubviews() {
        super.layoutSubviews()
        ring.frame = bounds.insetBy(dx: 4, dy: 4)
        ring.layer.cornerRadius = ring.bounds.width / 2
        knob.bounds = CGRect(x: 0, y: 0, width: bounds.width * 0.40, height: bounds.height * 0.40)
        knob.layer.cornerRadius = knob.bounds.width / 2
        updateKnob()
    }
    private func updateKnob() {
        knob.center = CGPoint(x: bounds.midX + direction.x * bounds.width * 0.27,
                              y: bounds.midY + direction.y * bounds.height * 0.27)
    }
    private func handle(_ touch: UITouch) {
        let p = touch.location(in: self)
        let r = max(1, bounds.width * 0.31)
        let dx = (p.x - bounds.midX) / r
        let dy = (p.y - bounds.midY) / r
        let length = max(1, hypot(dx, dy))
        direction = CGPoint(x: dx / length, y: dy / length)
        updateKnob()
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let t = touches.first { handle(t) }
    }
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let t = touches.first { handle(t) }
    }
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        direction = .zero; updateKnob()
    }
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        direction = .zero; updateKnob()
    }
}

final class HorrorGameViewController: UIViewController, UIGestureRecognizerDelegate, UIDocumentPickerDelegate {
    private let sceneView = SCNView(frame: .zero)
    private let scene = SCNScene()
    private let cameraNode = SCNNode()
    private let monsterNode = SCNNode()
    private let heroNode = SCNNode()
    private let viewButton = UIButton(type: .custom)
    private let modelsButton = UIButton(type: .system)
    private var selectedModelName: String?
    private var thirdPerson = true
    private let joystick = Joystick(frame: .zero)
    private let sprint = UIButton(type: .custom)
    private let torchButton = UIButton(type: .custom)
    private let pauseButton = UIButton(type: .custom)
    private let hud = UILabel()
    private let objective = UILabel()
    private let centerMessage = UILabel()
    private let overlay = UIView()
    private let overlayTitle = UILabel()
    private let overlayDetails = UILabel()
    private let overlayButton = UIButton(type: .system)
    private let crosshair = UILabel()
    private let menuBackground = UIImageView()
    private var screamPlayer: AVAudioPlayer?
    private var heroLegMorphs: [SCNMorpher] = []
    private var enemyLegMorphs: [SCNMorpher] = []

    private var link: CADisplayLink?
    private var lastTime: CFTimeInterval = 0
    private var yaw: Float = 0
    private var pitch: Float = 0
    private var playerX: Float = 0
    private var playerZ: Float = 8
    private var pickups: [Pickup] = []
    private var blockers: [Blocker] = []
    private var collected = 0
    private let targetCount = 3
    private var elapsed: Float = 0
    private var sprintDown = false
    private var torchEnabled = true
    private var paused = true
    private var finished = false
    private var started = false
    private var monsterActive = false
    private var messageUntil: Float = 0
    private var exitNode = SCNNode()
    private let flash = SCNLight()

    override var prefersStatusBarHidden: Bool { true }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .landscape }
    override var shouldAutorotate: Bool { true }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        setupScene()
        prepareAppearanceAudio()
        createWorld()
        createUI()
        showOverlay(title: "LOST CHAPTER", text: "FAN-MADE HORROR • CHAPTER 01\n\nCollect three custards. Avoid the infected. Escape through the gate.\n\nLEFT: MOVE    RIGHT: LOOK    RUN: SPRINT\nVIEW: SWITCH 1ST/3RD PERSON", button: "START CHAPTER")
        link = CADisplayLink(target: self, selector: #selector(tick(_:)))
        link?.preferredFramesPerSecond = 60
        link?.add(to: .main, forMode: .common)
    }

    deinit { link?.invalidate() }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        let w = view.bounds.width
        let h = view.bounds.height
        let safe = view.safeAreaInsets
        let baseY = h - max(112, h * 0.36) - safe.bottom
        joystick.frame = CGRect(x: max(18, safe.left + 16), y: baseY, width: 114, height: 114)
        sprint.frame = CGRect(x: w - max(100, safe.right + 95), y: h - 110 - safe.bottom, width: 78, height: 78)
        torchButton.frame = CGRect(x: w - max(104, safe.right + 98), y: 91, width: 84, height: 43)
        pauseButton.frame = CGRect(x: w - max(52, safe.right + 46), y: 23, width: 36, height: 36)
        viewButton.frame = CGRect(x: w - max(178, safe.right + 164), y: 21, width: 103, height: 42)
        hud.frame = CGRect(x: safe.left + 18, y: 17, width: min(w * 0.52, 370), height: 28)
        objective.frame = CGRect(x: safe.left + 18, y: 47, width: min(w * 0.67, 510), height: 37)
        centerMessage.frame = CGRect(x: w * 0.20, y: h * 0.19, width: w * 0.6, height: 50)
        crosshair.frame = CGRect(x: (w - 30) / 2, y: (h - 30) / 2, width: 30, height: 30)
        overlay.frame = view.bounds
        menuBackground.frame = overlay.bounds
        let cw = min(w - 70, 500.0)
        overlayTitle.frame = CGRect(x: (w - cw) / 2, y: h * 0.12, width: cw, height: 54)
        overlayDetails.frame = CGRect(x: (w - cw) / 2, y: h * 0.31, width: cw, height: h * 0.43)
        overlayButton.frame = CGRect(x: (w - min(cw, 290)) / 2, y: h - 83, width: min(cw, 290), height: 51)
        modelsButton.frame = CGRect(x: (w - min(cw, 290)) / 2, y: h - 133, width: min(cw, 290), height: 39)
    }

    private func setupScene() {
        sceneView.frame = view.bounds
        sceneView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        sceneView.scene = scene
        sceneView.backgroundColor = color(0x071014)
        sceneView.antialiasingMode = .none // low RAM cost on iPhone 12
        sceneView.isPlaying = true
        sceneView.rendersContinuously = true
        sceneView.preferredFramesPerSecond = 60
        view.addSubview(sceneView)

        scene.background.contents = color(0x071014)
        scene.lightingEnvironment.contents = color(0x17242B)
        scene.fogColor = color(0x10191E)
        scene.fogStartDistance = 14
        scene.fogEndDistance = 48

        let camera = SCNCamera()
        camera.fieldOfView = 75
        camera.zNear = 0.05
        camera.zFar = 85
        camera.wantsHDR = false
        cameraNode.camera = camera
        cameraNode.position = SCNVector3(0, 1.72, 8)
        scene.rootNode.addChildNode(cameraNode)
        sceneView.pointOfView = cameraNode

        flash.type = .spot
        flash.color = color(0xE3F1DC)
        flash.intensity = 780
        flash.spotInnerAngle = 19
        flash.spotOuterAngle = 54
        flash.attenuationEndDistance = 23
        flash.castsShadow = false
        let flashNode = SCNNode()
        flashNode.light = flash
        // Spotlight naturally points along the camera forward vector (-z).
        cameraNode.addChildNode(flashNode)
        flashNode.position = SCNVector3(0.20, -0.15, -0.24)

        let moon = SCNNode()
        moon.light = SCNLight()
        moon.light?.type = .directional
        moon.light?.color = color(0x8FA8BC)
        moon.light?.intensity = 480
        moon.eulerAngles = SCNVector3(-0.85, -0.4, 0)
        scene.rootNode.addChildNode(moon)
        let ambientNode = SCNNode()
        let ambient = SCNLight()
        ambient.type = .ambient
        ambient.color = color(0x33464C)
        ambient.intensity = 260
        ambientNode.light = ambient
        scene.rootNode.addChildNode(ambientNode)

        let pan = UIPanGestureRecognizer(target: self, action: #selector(look(_:)))
        pan.maximumNumberOfTouches = 1
        pan.delegate = self
        pan.cancelsTouchesInView = false
        sceneView.addGestureRecognizer(pan)
    }

    func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
        guard let p = gestureRecognizer as? UIPanGestureRecognizer else { return true }
        return p.location(in: sceneView).x > sceneView.bounds.width * 0.34
    }

    @objc private func look(_ recognizer: UIPanGestureRecognizer) {
        if paused { recognizer.setTranslation(.zero, in: sceneView); return }
        let t = recognizer.translation(in: sceneView)
        yaw -= Float(t.x) * 0.0041
        pitch = max(-0.95, min(0.95, pitch - Float(t.y) * 0.0033))
        recognizer.setTranslation(.zero, in: sceneView)
    }

    private func prepareAppearanceAudio() {
        let url = Bundle.main.url(forResource: "tinky_appearance", withExtension: "mp3", subdirectory: "Audio")
                  ?? Bundle.main.url(forResource: "tinky_appearance", withExtension: "mp3")
        guard let url = url else { NSLog("Tinky scream audio missing"); return }
        do {
            screamPlayer = try AVAudioPlayer(contentsOf: url)
            screamPlayer?.volume = 0.82
            screamPlayer?.prepareToPlay()
        } catch { NSLog("Scream playback error: \(error)") }
    }

    private func makeMaterialsOpaque(_ node: SCNNode) {
        node.enumerateHierarchy { part, _ in
            guard let geometry = part.geometry else { return }
            for mat in geometry.materials {
                mat.transparency = 1.0
                mat.transparent.contents = UIColor.white
                mat.blendMode = .replace
                mat.writesToDepthBuffer = true
                mat.readsFromDepthBuffer = true
                mat.isDoubleSided = true
            }
        }
    }

    // Small vertex morphs to give the uploaded non-rigged meshes a visible stepping motion.
    // Original textures, UV coordinates and topology remain unchanged.
    private func addLegMorphs(to model: SCNNode) -> [SCNMorpher] {
        var output: [SCNMorpher] = []
        model.enumerateHierarchy { part, _ in
            guard let geometry = part.geometry,
                  let vertices = geometry.sources.first(where: { $0.semantic == .vertex }),
                  vertices.usesFloatComponents, vertices.bytesPerComponent == 4,
                  vertices.componentsPerVector >= 3 else { return }
            // Head/hat are above the hips and remain unmodified.
            let plus = morphedGeometry(geometry, vertices: vertices, sign: 1)
            let minus = morphedGeometry(geometry, vertices: vertices, sign: -1)
            guard let a = plus, let b = minus else { return }
            let morpher = SCNMorpher()
            morpher.calculationMode = .normalized
            morpher.targets = [a, b]
            part.morpher = morpher
            output.append(morpher)
        }
        return output
    }

    private func morphedGeometry(_ base: SCNGeometry, vertices: SCNGeometrySource, sign: Float) -> SCNGeometry? {
        var bytes = Array(vertices.data)
        let step = vertices.dataStride
        let offset = vertices.dataOffset
        guard step >= 12, offset >= 0, bytes.count >= offset + step * max(vertices.vectorCount - 1, 0) + 12 else { return nil }
        func read(_ idx: Int) -> Float {
            let n = UInt32(bytes[idx]) | (UInt32(bytes[idx+1]) << 8) |
                    (UInt32(bytes[idx+2]) << 16) | (UInt32(bytes[idx+3]) << 24)
            return Float(bitPattern: n)
        }
        func write(_ idx: Int, _ value: Float) {
            let n = value.bitPattern.littleEndian
            bytes[idx] = UInt8(truncatingIfNeeded: n)
            bytes[idx+1] = UInt8(truncatingIfNeeded: n >> 8)
            bytes[idx+2] = UInt8(truncatingIfNeeded: n >> 16)
            bytes[idx+3] = UInt8(truncatingIfNeeded: n >> 24)
        }
        for i in 0..<vertices.vectorCount {
            let j = offset + i * step
            let x = read(j), y = read(j+4), z = read(j+8)
            // Main body: only below hips (about y = 1.12m).
            let influence = pow(max(0, min(1, (1.15 - y) / 0.83)), 1.35)
            let leg: Float = x >= 0 ? 1 : -1
            let motion = sign * leg * influence
            write(j+8, z + motion * 0.20)
            write(j+4, y + max(0, motion) * 0.05)
        }
        let vSource = SCNGeometrySource(data: Data(bytes), semantic: .vertex,
                                        vectorCount: vertices.vectorCount,
                                        usesFloatComponents: true,
                                        componentsPerVector: vertices.componentsPerVector,
                                        bytesPerComponent: vertices.bytesPerComponent,
                                        dataOffset: offset,
                                        dataStride: step)
        let sources = base.sources.map { $0.semantic == .vertex ? vSource : $0 }
        let result = SCNGeometry(sources: sources, elements: base.elements)
        result.materials = base.materials
        return result
    }

    private func updateLegMorphs(_ morphers: [SCNMorpher], phase: Float, amount: Float) {
        let value = sin(phase) * amount
        for morpher in morphers {
            morpher.setWeight(CGFloat(max(0, value)), forTargetAt: 0)
            morpher.setWeight(CGFloat(max(0, -value)), forTargetAt: 1)
        }
    }

    private func createWorld() {
        // Map v0.7 from user supplied Main Land GLB, pre-converted to textured OBJ.
        // Small fallback underlay protects against invisible gaps in a ripped map.
        let floor = SCNNode(geometry: SCNPlane(width: 72, height: 110))
        floor.eulerAngles.x = -.pi / 2
        floor.position = SCNVector3(0, -0.30, -15)
        floor.geometry?.firstMaterial = material(0x29342A)
        scene.rootNode.addChildNode(floor)

        if let map = modelRoot("main_land") {
            makeMaterialsOpaque(map)
            scene.rootNode.addChildNode(map)
            NSLog("Loaded textured Main Land v0.7 environment")
        } else {
            // Obvious diagnostic if some original asset is absent in the bundle.
            NSLog("Missing Main Land OBJ: level geometry unavailable")
            let label = SCNText(string: "MAIN LAND MODEL MISSING", extrusionDepth: 0.04)
            label.font = .systemFont(ofSize: 0.5)
            let marker = SCNNode(geometry: label)
            marker.position = SCNVector3(-5, 1, -3)
            scene.rootNode.addChildNode(marker)
        }
        // Keep mechanics and the pre-existing gate, objective, pursuer and player.
        // No extra procedural trees, dummy sheds, or grey cubes are placed over the map.
        addGate()
        addPickups()
        addMonster()
        addHero()

        for i in 0..<36 {
            let fi = Float(i)
            let p = SCNNode(geometry: SCNSphere(radius: 0.018))
            p.geometry?.firstMaterial = material(0xA1B59A, emission: 0x293B2C)
            p.position = SCNVector3(sin(fi * 2.77) * 9, 1.4 + abs(sin(fi * 0.73)) * 2.2, 5 - fi * 1.3)
            scene.rootNode.addChildNode(p)
        }
    }

    // User-provided models are stored in Documents/ImportedModels; originals are NOT
    // bundled or represented as bundled. Models selected in Files must be USDZ, DAE,
    // OBJ or SCN; GLB/FBX can be converted during CI before compiling the game.
    private func importedModelsFolder() -> URL {
        let base = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        return base.appendingPathComponent("ImportedModels", isDirectory: true)
    }

    private func userModelURL(_ name: String) -> URL? {
        for ext in ["usdz", "dae", "scn", "obj"] {
            let url = importedModelsFolder().appendingPathComponent("\(name).\(ext)")
            if FileManager.default.fileExists(atPath: url.path) { return url }
        }
        return nil
    }

    private func sceneNode(from url: URL, normalized: Bool) -> SCNNode? {
        guard let imported = try? SCNScene(url: url, options: nil) else { return nil }
        let parent = SCNNode()
        imported.rootNode.childNodes.forEach { parent.addChildNode($0.clone()) }
        guard !parent.childNodes.isEmpty else { return nil }
        if normalized {
            // Fit arbitrary community models to the world scale; models retain
            // their original meshes/materials rather than being generated as shapes.
            var low = SCNVector3Zero
            var high = SCNVector3Zero
            if parent.getBoundingBoxMin(&low, max: &high) {
                let height = max(0.001, high.y - low.y)
                let factor = min(10.0, max(0.01, 2.15 / height))
                let container = SCNNode()
                parent.scale = SCNVector3(factor, factor, factor)
                parent.position = SCNVector3(-(low.x + high.x) * 0.5 * factor,
                                             -low.y * factor,
                                             -(low.z + high.z) * 0.5 * factor)
                container.addChildNode(parent)
                return container
            }
        }
        return parent
    }

    private func modelRoot(_ name: String) -> SCNNode? {
        if let userURL = userModelURL(name),
           let model = sceneNode(from: userURL, normalized: true) {
            NSLog("Loaded personal model for \(name): \(userURL.lastPathComponent)")
            return model
        }
        // v0.7: bundled user-supplied GLBs pre-converted to textured OBJ.
        // Guardian and Tinky Winky are actors; Main Land and Custard are world assets.
        // OBJ + adjacent MTL/PNG were converted from the uploaded GLB without
        // procedurally substituting simplified character meshes.
        if ["guardian", "infected", "main_land", "tubby_custard"].contains(name) {
            if let url = Bundle.main.url(forResource: name, withExtension: "obj",
                                         subdirectory: "Models.scnassets"),
               let model = sceneNode(from: url, normalized: false) { return model }
            if let modelScene = SCNScene(named: "Models.scnassets/\(name).obj") {
                let parent = SCNNode()
                modelScene.rootNode.childNodes.forEach { parent.addChildNode($0.clone()) }
                if !parent.childNodes.isEmpty { return parent }
            }
        }
        for asset in ["Models.scnassets/\(name).dae", "Models.scnassets/\(name).scn"] {
            if let bundleURL = Bundle.main.url(forResource: name,
                                               withExtension: asset.hasSuffix("dae") ? "dae" : "scn",
                                               subdirectory: "Models.scnassets"),
               let model = sceneNode(from: bundleURL, normalized: false) {
                return model
            }
            if let bundled = SCNScene(named: asset) {
                let parent = SCNNode()
                bundled.rootNode.childNodes.forEach { parent.addChildNode($0.clone()) }
                if !parent.childNodes.isEmpty { return parent }
            }
        }
        return nil
    }

    private func replaceDisplayedModel(_ name: String) {
        guard name == "guardian" || name == "infected" else { return }
        let owner = name == "guardian" ? heroNode : monsterNode
        guard let newModel = modelRoot(name) else { return }
        owner.childNodes.forEach { $0.removeFromParentNode() }
        makeMaterialsOpaque(newModel)
        owner.addChildNode(newModel)
        let isPersonal = userModelURL(name) != nil
        // The two bundled OBJs have been normalized to 2.15 m world height.
        let hasBundledOBJ = Bundle.main.url(forResource: name, withExtension: "obj",
                                            subdirectory: "Models.scnassets") != nil
        let factor: Float = (isPersonal || hasBundledOBJ) ? 1.0 : (name == "guardian" ? 0.70 : 0.84)
        owner.scale = SCNVector3(factor, factor, factor)
        // These community GLB meshes contain no skeleton or animation tracks.
        // Do not claim that individual limbs animate; the actor moves via game AI.
        // Create mild vertex morphs for walking on rigid uploaded meshes.
        // There is NO skeleton in the GLBs: this is procedural deformation, not rigged animation.
        let morphers = addLegMorphs(to: newModel)
        if name == "guardian" { heroLegMorphs = morphers }
        else { enemyLegMorphs = morphers }
    }

    @objc private func chooseModelToImport() {
        let menu = UIAlertController(title: "3D MODELS · V0.7",
                                     message: "Guardian, Tinky Winky, Main Land and Custard are bundled in v0.7. You can still import another model via Files. USDZ/DAE/OBJ/SCN are supported.",
                                     preferredStyle: .actionSheet)
        for (name, label) in [("guardian", "GUARDIAN / ХРАНИТЕЛЬ"),
                              ("infected", "INFECTED / МОНСТР")] {
            menu.addAction(UIAlertAction(title: label, style: .default) { [weak self] _ in
                guard let self = self else { return }
                self.selectedModelName = name
                let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.item], asCopy: true)
                picker.delegate = self
                self.present(picker, animated: true)
            })
        }
        menu.addAction(UIAlertAction(title: "CANCEL", style: .cancel))
        // Actionsheet on iPad requires a popover anchor even though app targets iPhone.
        menu.popoverPresentationController?.sourceView = modelsButton
        menu.popoverPresentationController?.sourceRect = modelsButton.bounds
        present(menu, animated: true)
    }

    func documentPicker(_ controller: UIDocumentPickerViewController,
                        didPickDocumentsAt urls: [URL]) {
        guard let url = urls.first, let role = selectedModelName else { return }
        selectedModelName = nil
        let ext = url.pathExtension.lowercased()
        guard ["usdz", "dae", "scn", "obj"].contains(ext) else {
            modelNotice("This format isn't supported directly. Use USDZ/DAE/OBJ/SCN; convert GLB/FBX using the included GitHub workflow.")
            return
        }
        let access = url.startAccessingSecurityScopedResource()
        defer { if access { url.stopAccessingSecurityScopedResource() } }
        let fm = FileManager.default
        do {
            try fm.createDirectory(at: importedModelsFolder(), withIntermediateDirectories: true)
            let trial = importedModelsFolder().appendingPathComponent("trial_\(role).\(ext)")
            try? fm.removeItem(at: trial)
            try fm.copyItem(at: url, to: trial)
            guard sceneNode(from: trial, normalized: true) != nil else {
                try? fm.removeItem(at: trial)
                modelNotice("Unable to read this 3D file. Try an exported USDZ or DAE model.")
                return
            }
            for oldExt in ["usdz", "dae", "scn", "obj"] {
                try? fm.removeItem(at: importedModelsFolder().appendingPathComponent("\(role).\(oldExt)"))
            }
            try fm.moveItem(at: trial, to: importedModelsFolder().appendingPathComponent("\(role).\(ext)"))
            replaceDisplayedModel(role)
            modelNotice("Model imported: \(role). Restarting the app will keep this model. The actual creator/licence is not verified by the app.")
        } catch {
            modelNotice("Could not import: \(error.localizedDescription)")
        }
    }

    private func modelNotice(_ message: String) {
        let alert = UIAlertController(title: "MODEL IMPORT", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }

    private func addTree(x: Float, z: Float, scale: Float) {
        guard let tree = modelRoot("forest_tree") else {
            // If an asset is unexpectedly missing, show an obvious error instead of an invisible level.
            NSLog("Missing model: forest_tree.dae")
            return
        }
        tree.position = SCNVector3(x, 0, z)
        tree.eulerAngles.y = sin(x * 0.77 + z * 1.91) * 3
        tree.scale = SCNVector3(scale * 0.94, scale, scale * 0.94)
        scene.rootNode.addChildNode(tree)
        blockers.append(Blocker(x: x, z: z, halfW: 0.35 * scale, halfD: 0.35 * scale))
    }

    private func animateWalk(_ node: SCNNode, infected: Bool) {
        // Moving body parts instead of sliding a motionless figurine across the floor.
        node.enumerateChildNodes { child, _ in
            guard let name = child.name?.lowercased() else { return }
            if name.hasSuffix("_arm") || name.hasSuffix("_leg") {
                let left = name.hasPrefix("left")
                let amplitude: CGFloat = infected ? 0.38 : 0.26
                let sign: CGFloat = left ? 1 : -1
                let action = SCNAction.repeatForever(.sequence([
                    .rotateBy(x: sign * amplitude, y: 0, z: 0, duration: 0.24),
                    .rotateBy(x: -sign * amplitude * 2, y: 0, z: 0, duration: 0.48),
                    .rotateBy(x: sign * amplitude, y: 0, z: 0, duration: 0.24)
                ]))
                child.runAction(action)
            }
        }
    }

    private func addHero() {
        heroNode.position = SCNVector3(0, 0, 8)
        heroNode.isHidden = !thirdPerson
        scene.rootNode.addChildNode(heroNode)
        replaceDisplayedModel("guardian")
    }

    private func addShed(x: Float, z: Float) {
        let shed = SCNNode()
        shed.position = SCNVector3(x, 0, z)
        let base = box(6, 3.4, 5.2, 0x515D5D)
        base.position.y = 1.7
        shed.addChildNode(base)
        let roof = box(6.5, 0.33, 5.7, 0x202729)
        roof.position.y = 3.55
        shed.addChildNode(roof)
        let door = box(1.5, 2.4, 0.06, 0x232A2D)
        door.position = SCNVector3(0.9, 1.2, 2.65)
        shed.addChildNode(door)
        let redLight = SCNNode(geometry: SCNSphere(radius: 0.12))
        redLight.geometry?.firstMaterial = material(0xCC2727, emission: 0xFF2424)
        redLight.position = SCNVector3(0.9, 2.9, 2.72)
        shed.addChildNode(redLight)
        scene.rootNode.addChildNode(shed)
        blockers.append(Blocker(x: x, z: z, halfW: 3.25, halfD: 2.85))
    }

    private func addGate() {
        let gate = SCNNode()
        gate.position = SCNVector3(0, 0, -39.0)
        let left = box(0.85, 5, 1.15, 0x686A61)
        left.position = SCNVector3(-2.45, 2.5, 0)
        let right = box(0.85, 5, 1.15, 0x686A61)
        right.position = SCNVector3(2.45, 2.5, 0)
        let top = box(6.0, 0.95, 1.1, 0x454F51)
        top.position = SCNVector3(0, 4.65, 0)
        gate.addChildNode(left); gate.addChildNode(right); gate.addChildNode(top)
        let stripe = box(4.0, 0.2, 0.10, 0xBB4D2D)
        stripe.position = SCNVector3(0, 3.5, 0.57)
        gate.addChildNode(stripe)
        let beacon = SCNNode(geometry: SCNSphere(radius: 0.23))
        beacon.geometry?.firstMaterial = material(0xFF5426, emission: 0xFF451A)
        beacon.position = SCNVector3(0, 4.0, 0.70)
        gate.addChildNode(beacon)
        scene.rootNode.addChildNode(gate)
        exitNode = gate
        blockers.append(Blocker(x: -2.45, z: -39, halfW: 0.55, halfD: 0.7))
        blockers.append(Blocker(x: 2.45, z: -39, halfW: 0.55, halfD: 0.7))
    }

    private func addScarySign() {
        let post = box(0.13, 2.2, 0.13, 0x38332D)
        post.position = SCNVector3(2.9, 1.1, 1.0)
        let sign = box(2.2, 0.65, 0.14, 0x777358)
        sign.position = SCNVector3(2.9, 2.05, 1.0)
        scene.rootNode.addChildNode(post)
        scene.rootNode.addChildNode(sign)
        let textGeometry = SCNText(string: "RESTRICTED", extrusionDepth: 0.01)
        textGeometry.font = .boldSystemFont(ofSize: 0.19)
        textGeometry.firstMaterial = material(0x191F1B)
        let label = SCNNode(geometry: textGeometry)
        label.position = SCNVector3(2.09, 1.96, 1.09)
        scene.rootNode.addChildNode(label)
    }

    private func addPickups() {
        // Three real Tubby Custard meshes from user's uploaded GLB.
        // A dim halo is only a gameplay marker, not a replacement for the cup.
        for location in [(4.0 as Float, -6.0 as Float), (-4.5, -18.0), (4.7, -31.0)] {
            let pickup = SCNNode()
            guard let cup = modelRoot("tubby_custard") else {
                NSLog("Missing Tubby Custard OBJ: pickup at \(location) unavailable")
                continue
            }
            makeMaterialsOpaque(cup)
            pickup.addChildNode(cup)
            let halo = SCNNode(geometry: SCNTorus(ringRadius: 0.37, pipeRadius: 0.018))
            halo.geometry?.firstMaterial = material(0xBE87B6, emission: 0x7C486E)
            halo.position.y = 0.08
            pickup.addChildNode(halo)
            pickup.position = SCNVector3(location.0, 0.08, location.1)
            scene.rootNode.addChildNode(pickup)
            pickups.append(Pickup(node: pickup, position: pickup.position))
        }
    }

    private func addMonster() {
        monsterNode.position = SCNVector3(9, 0, -27)
        monsterNode.isHidden = true
        scene.rootNode.addChildNode(monsterNode)
        replaceDisplayedModel("infected")
    }

    private func createUI() {
        let white = UIColor.white
        func hudText(_ label: UILabel, size: CGFloat, alignment: NSTextAlignment = .left) {
            label.font = .monospacedSystemFont(ofSize: size, weight: .bold)
            label.textColor = white
            label.textAlignment = alignment
            label.numberOfLines = 2
            label.shadowColor = .black
            label.shadowOffset = CGSize(width: 1, height: 2)
            view.addSubview(label)
        }
        view.addSubview(joystick)
        func setupButton(_ button: UIButton, _ title: String) {
            button.setTitle(title, for: .normal)
            button.titleLabel?.font = .systemFont(ofSize: 14, weight: .heavy)
            button.setTitleColor(.white, for: .normal)
            button.backgroundColor = color(0x26342F, a: 0.68)
            button.layer.borderColor = color(0x91D5AF, a: 0.63).cgColor
            button.layer.borderWidth = 1.5
            button.layer.cornerRadius = 18
            view.addSubview(button)
        }
        setupButton(sprint, "RUN")
        sprint.layer.cornerRadius = 39
        setupButton(torchButton, "LIGHT")
        setupButton(pauseButton, "II")
        setupButton(viewButton, "1ST VIEW")
        sprint.addTarget(self, action: #selector(runOn), for: .touchDown)
        sprint.addTarget(self, action: #selector(runOff), for: [.touchUpInside, .touchUpOutside, .touchCancel])
        torchButton.addTarget(self, action: #selector(toggleTorch), for: .touchUpInside)
        pauseButton.addTarget(self, action: #selector(togglePause), for: .touchUpInside)
        viewButton.addTarget(self, action: #selector(toggleView), for: .touchUpInside)
        hudText(hud, size: 20)
        hudText(objective, size: 13)
        hudText(centerMessage, size: 17, alignment: .center)
        hudText(crosshair, size: 23, alignment: .center)
        crosshair.text = "+"
        crosshair.textColor = color(0xBDE1CC, a: 0.7)
        hud.text = "CUSTARDS  0 / 3"
        objective.text = "FIND THE CUSTARD. STAY QUIET."
        centerMessage.alpha = 0
        overlay.backgroundColor = .black
        view.addSubview(overlay)
        let bgURL = Bundle.main.url(forResource: "menu_background", withExtension: "jpg", subdirectory: "")
                  ?? Bundle.main.url(forResource: "menu_background", withExtension: "jpg")
        if let bgURL = bgURL { menuBackground.image = UIImage(contentsOfFile: bgURL.path) }
        menuBackground.contentMode = .scaleAspectFill
        menuBackground.clipsToBounds = true
        menuBackground.alpha = 0.75
        overlay.addSubview(menuBackground)
        overlayTitle.text = "LOST CHAPTER"
        overlayTitle.textColor = color(0xF0E9DC)
        overlayTitle.layer.shadowColor = UIColor.black.cgColor
        overlayTitle.layer.shadowOpacity = 1
        overlayTitle.layer.shadowRadius = 6
        overlayTitle.layer.shadowOffset = CGSize(width: 2, height: 2)
        overlayTitle.font = UIFont(name: "Georgia-Bold", size: 34) ?? .systemFont(ofSize: 34, weight: .black)
        overlayTitle.textAlignment = .center
        overlay.addSubview(overlayTitle)
        overlayDetails.textColor = color(0xD7D2C9)
        overlayDetails.font = .systemFont(ofSize: 15, weight: .medium)
        overlayDetails.textAlignment = .center
        overlayDetails.numberOfLines = 0
        overlay.addSubview(overlayDetails)
        overlayButton.setTitleColor(color(0xF1E8DF), for: .normal)
        overlayButton.titleLabel?.font = UIFont(name: "Georgia-Bold", size: 21) ?? .boldSystemFont(ofSize: 21)
        overlayButton.backgroundColor = color(0x230B11, a: 0.86)
        overlayButton.layer.borderColor = color(0xA14D55).cgColor
        overlayButton.layer.borderWidth = 1.5
        overlayButton.layer.cornerRadius = 4
        overlayButton.addTarget(self, action: #selector(overlayTapped), for: .touchUpInside)
        overlay.addSubview(overlayButton)
        modelsButton.setTitle("IMPORT 3D MODEL (FILES)", for: .normal)
        modelsButton.setTitleColor(color(0xE6DBCC), for: .normal)
        modelsButton.titleLabel?.font = .systemFont(ofSize: 13, weight: .bold)
        modelsButton.layer.borderColor = color(0x6A3638, a: 0.9).cgColor
        modelsButton.layer.borderWidth = 1
        modelsButton.layer.cornerRadius = 4
        modelsButton.addTarget(self, action: #selector(chooseModelToImport), for: .touchUpInside)
        overlay.addSubview(modelsButton)
        view.setNeedsLayout()
    }

    private func showOverlay(title: String, text: String, button: String) {
        paused = true
        overlayTitle.text = title
        overlayDetails.text = text
        overlayButton.setTitle(button, for: .normal)
        modelsButton.isHidden = false
        overlay.isHidden = false
        joystick.isHidden = true
        sprint.isHidden = true
        torchButton.isHidden = true
        crosshair.isHidden = true
        pauseButton.isHidden = true
        viewButton.isHidden = true
    }

    private func dismissOverlay() {
        paused = false
        overlay.isHidden = true
        joystick.isHidden = false
        sprint.isHidden = false
        torchButton.isHidden = false
        crosshair.isHidden = false
        pauseButton.isHidden = false
        viewButton.isHidden = false
        lastTime = 0
    }

    @objc private func overlayTapped() {
        if finished { reset() }
        started = true
        dismissOverlay()
        say("Find the first custard.", for: 3.3)
    }

    @objc private func toggleView() {
        thirdPerson.toggle()
        heroNode.isHidden = !thirdPerson
        viewButton.setTitle(thirdPerson ? "1ST VIEW" : "3RD VIEW", for: .normal)
    }

    @objc private func runOn() { sprintDown = true }
    @objc private func runOff() { sprintDown = false }
    @objc private func toggleTorch() {
        torchEnabled.toggle()
        flash.intensity = torchEnabled ? 780 : 0
        torchButton.setTitle(torchEnabled ? "LIGHT" : "OFF", for: .normal)
    }
    @objc private func togglePause() {
        sprintDown = false
        showOverlay(title: "PAUSED", text: "CHAPTER 01 — MAIN LAND\n\nCollect 3 custards to open the gate.\nRun when the infected sees you.", button: "RESUME")
    }
    private func say(_ text: String, for seconds: Float) {
        centerMessage.text = text
        centerMessage.alpha = 1
        messageUntil = elapsed + seconds
    }

    private func blocked(_ x: Float, _ z: Float) -> Bool {
        if abs(x) > 29 || z > 14 || z < -43 { return true }
        for b in blockers {
            if abs(x - b.x) < b.halfW + 0.27 && abs(z - b.z) < b.halfD + 0.27 { return true }
        }
        return false
    }

    @objc private func tick(_ display: CADisplayLink) {
        defer { lastTime = display.timestamp }
        guard started, !paused else { return }
        let dt = lastTime == 0 ? 0.016 : min(Float(display.timestamp - lastTime), 0.045)
        elapsed += dt
        let j = joystick.direction
        let forward = -Float(j.y)
        let lateral = Float(j.x)
        let velocity: Float = sprintDown ? 5.5 : 3.1
        let xVelocity = (sin(yaw) * forward + cos(yaw) * lateral) * velocity * dt
        let zVelocity = (-cos(yaw) * forward + sin(yaw) * lateral) * velocity * dt
        if !blocked(playerX + xVelocity, playerZ) { playerX += xVelocity }
        if !blocked(playerX, playerZ + zVelocity) { playerZ += zVelocity }
        let bob = sin(elapsed * (sprintDown ? 12 : 8)) * (abs(j.x) + abs(j.y) > 0.3 ? 0.026 : 0)
        heroNode.position = SCNVector3(playerX, bob, playerZ)
        heroNode.eulerAngles.y = yaw
        let walking = abs(j.x) + abs(j.y) > 0.16
        updateLegMorphs(heroLegMorphs, phase: elapsed * (sprintDown ? 14 : 9), amount: walking ? 0.75 : 0)
        if thirdPerson {
            cameraNode.position = SCNVector3(playerX - sin(yaw) * 3.05, 2.57 + bob, playerZ + cos(yaw) * 3.05)
            cameraNode.eulerAngles = SCNVector3(pitch - 0.20, yaw, 0)
        } else {
            cameraNode.position = SCNVector3(playerX, 1.72 + bob, playerZ)
            cameraNode.eulerAngles = SCNVector3(pitch, yaw, 0)
        }
        for item in pickups {
            item.node.eulerAngles.y += dt * 0.65
            item.node.position.y = item.position.y + sin(elapsed * 2) * 0.06
        }
        for i in pickups.indices.reversed() {
            let p = pickups[i].position
            if hypot(p.x - playerX, p.z - playerZ) < 1.4 {
                pickups[i].node.removeFromParentNode()
                pickups.remove(at: i)
                collected += 1
                hud.text = "CUSTARDS  \(collected) / \(targetCount)"
                if collected == 1 {
                    monsterActive = true
                    monsterNode.isHidden = false
                    screamPlayer?.currentTime = 0
                    screamPlayer?.play()
                    say("TINKY WINKY! RUN!", for: 3.0)
                } else if collected < targetCount {
                    say("Keep moving. Don't let it catch you.", for: 3)
                } else {
                    objective.text = "ALL CUSTARDS FOUND — REACH THE RED GATE"
                    say("The escape gate is open. RUN!", for: 4)
                }
            }
        }
        if centerMessage.alpha > 0 && elapsed > messageUntil { centerMessage.alpha = 0 }
        if monsterActive { moveMonster(dt: dt) }
        if collected == targetCount && abs(playerX) < 2.0 && abs(playerZ + 39) < 1.8 {
            win()
        }
    }

    private func moveMonster(dt: Float) {
        let mx = monsterNode.position.x
        let mz = monsterNode.position.z
        let dx = playerX - mx
        let dz = playerZ - mz
        let d = max(0.0001, hypot(dx, dz))
        let speed: Float = d < 18 ? 1.85 : 0.80
        if d < 40 {
            monsterNode.position.x += dx / d * speed * dt
            monsterNode.position.z += dz / d * speed * dt
        }
        monsterNode.eulerAngles.y = atan2(dx, dz)
        monsterNode.position.y = abs(sin(elapsed * 5.5)) * 0.045
        updateLegMorphs(enemyLegMorphs, phase: elapsed * 11.5, amount: d < 40 ? 0.95 : 0)
        if d < 1.1 { lose() }
    }

    private func win() {
        finished = true
        showOverlay(title: "YOU ESCAPED", text: "CHAPTER 01 COMPLETE\n\nThe infected is still out there.\n\nMore chapters are not yet implemented.", button: "PLAY AGAIN")
    }
    private func lose() {
        finished = true
        showOverlay(title: "YOU WERE CAUGHT", text: "TINKY WINKY CAUGHT YOU.\n\nTry sprinting around trees and use the fog to escape.", button: "TRY AGAIN")
    }
    private func reset() {
        elapsed = 0
        collected = 0
        playerX = 0
        playerZ = 8
        yaw = 0
        pitch = 0
        sprintDown = false
        joystick.direction = .zero
        monsterActive = false
        screamPlayer?.stop()
        monsterNode.isHidden = true
        monsterNode.position = SCNVector3(9, 0, -27)
        finished = false
        hud.text = "CUSTARDS  0 / 3"
        objective.text = "FIND THE CUSTARD. STAY QUIET."
        for p in pickups { p.node.removeFromParentNode() }
        pickups.removeAll()
        addPickups()
        centerMessage.alpha = 0
    }
}
