Place user-supplied guardian.glb/guardian.fbx and/or infected.glb/infected.fbx here. Files are NOT bundled.
